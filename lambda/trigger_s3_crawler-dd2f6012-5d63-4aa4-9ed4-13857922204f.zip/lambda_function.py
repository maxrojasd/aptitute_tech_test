import json
import psycopg2
import json
import os


def lambda_handler(event, context):
    # Assuming the Lambda function is triggered by an S3 event
    for record in event['Records']:
        # Extract bucket and key information
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key'].split('/')[2].split('.')[0]
    # TODO implement

    #Obtaining the connection to RedShift
    host = os.environ['host']
    user = os.environ['user']
    password = os.environ['password'] 
    port = os.environ['port']
    role = os.environ['role']

    con=psycopg2.connect(dbname= 'dev', host=host, port=port, user=user, password=password)
    #Copy Command as Variable
    copy_command=f"""copy dev.public.{key} (location, value, unit, pollutant, country, city, name, timestamp, longitude, latitude, date, time, day, month, year, hour, minute, second)
    from 's3://aptitudetestopenaq/records/' 
    iam_role '{role}'
    FORMAT AS PARQUET;"""
    #Opening a cursor and run copy query
    cur = con.cursor()
    cur.execute(f"truncate table {key};")
    cur.execute(copy_command)
    con.commit()
    
    #Close the cursor and the connection
    cur.close()
    con.close()

    
  